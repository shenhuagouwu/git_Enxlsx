# 联系项目

# 命令

1. 安装

```
yarn
```
2. 运行开发环境

```
yarn start
```

3. 输出测试环境

```
yarn test
```

4. 输出生产环境

```
yarn build
```