const getters = {
    editorType: state => state.leftnav.editorType,
    databox: state => state.printdata.databox,
};
export default getters;