import Cookies from 'js-cookie';
const state = {
    databox: Cookies.get('databox') ? Cookies.get('databox') : ''
};
const mutations = {
    handleClick(state,databox){
        state.databox = databox;
        Cookies.set('databox', databox);
        console.log("3-:" + databox);
        console.log("4-:" + this.databox);
        console.log("调用vuex后的databox:" + databox);
    }
};
const actions = {
    handleClick(ctx,databox) {
        console.log("1-:" + databox);
        ctx.commit('handleClick',databox);
        console.log("2-:" + databox);
    }
};

export default {
    namespaced: true,
    state,
    mutations,
    actions
};