<template>
  <div class="list">
    新闻分类
  </div>
</template>

<script>
export default {
  name: "newPage"
};
</script>

<style>
.list {
  font-size: 100px;
  color: red;
  line-height: 1;
}
</style>
