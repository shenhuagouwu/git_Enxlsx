<template>
  <div class="list">视频分类</div>
</template>

<script>
export default {
  name: 'videoPage'
}
</script>

<style>
    .list {
    font-size: 100px;
    color: red;
    line-height: 1;
    }
</style>
