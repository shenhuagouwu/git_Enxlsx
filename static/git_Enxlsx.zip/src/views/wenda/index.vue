<template>
  <div class="list">问答分类</div>
</template>

<script>
export default {
  name: 'wendaPage'
}
</script>

<style>
    .list {
    font-size: 100px;
    color: red;
    line-height: 1;
    }
</style>
